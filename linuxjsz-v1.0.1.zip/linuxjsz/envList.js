const envList = [{"envId":"linux-4g5syjom10c056b8","alias":"linux"}]
const isMac = false
module.exports = {
    envList,
    isMac
}