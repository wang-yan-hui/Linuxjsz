// app.js
// App({
//   onLaunch: function () {
//     this.globalData = {};
//   }
// });
