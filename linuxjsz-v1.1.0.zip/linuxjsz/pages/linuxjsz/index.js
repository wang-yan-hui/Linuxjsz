// index.js
// const app = getApp()
const { envList } = require('../../envList.js');

Page({
  data: {
    showUploadTip: false,
    powerList: [{
      title: '学习Nginx（十一）：反向代理与Tomcat动静分离配置',
      tip: '2024-05-21',
      link: 'https://mp.weixin.qq.com/s/tp6gTxUr_u6fkks0a99u0g',
    }, {
      title: 'Update! Tomcat部署脚本',
      tip: '2024-05-20',
      link: 'https://mp.weixin.qq.com/s/sbQJjZL8s6V7gL1fIfIsdg',
    }, {
      title: '学习Nginx（十）：提升网站负载之expires缓存',
      tip: '2024-05-19',
      link: 'https://mp.weixin.qq.com/s/eVgmQ3Yx7yCHhBhCgq2b9w',
    }, {
      title: '学习Nginx（九）：提升网站速度之gzip压缩',
      tip: '2024-05-18',
      link: 'https://mp.weixin.qq.com/s/7SzJ8aOsxQGUOR0pGswZHg',
    }, {
      title: '学习Nginx（八）：rewrite、if、set',
      tip: '2024-05-17',
      link: 'https://mp.weixin.qq.com/s/Hh94s2kDbIXCz9poi91rbw',
    }, {
      title: '学习Nginx（七）：Location的URI解析',
      tip: '2024-05-15',
      link: 'https://mp.weixin.qq.com/s/sjbGIG8NWcENoNaa94VSCg',
    }, {
      title: '学习Nginx（六）：日志管理',
      tip: '2024-05-14',
      link: 'https://mp.weixin.qq.com/s/st37BlvPWUs9XJdrf04VMg',
    }, {
      title: '学习Nginx（五）：虚拟主机配置',
      tip: '2024-05-13',
      link: 'https://mp.weixin.qq.com/s/ERk0Or9FBSASSGQKYrRqgQ',
    }, {
      title: '学习Nginx（四）：平滑升级与回滚',
      tip: '2024-05-12',
      link: 'https://mp.weixin.qq.com/s/qUyN3ZoAaKncBl9kUB0cXA',
    }, {
      title: '学习Nginx（三）：命令与信号',
      tip: '2024-05-11',
      link: 'https://mp.weixin.qq.com/s/PIMZ4FdSlnXbQXb5Z469SA',
    }, {
      title: '学习Nginx（二）：版本介绍和安装',
      tip: '2024-05-10',
      link: 'https://mp.weixin.qq.com/s/GsbMI0RVjTYpFL6AyTQSFQ',
    }, {
      title: '学习Nginx（一）：基础',
      tip: '2024-05-07',
      link: 'https://mp.weixin.qq.com/s/PK_ZHQvfY4OLuNj7oNs90Q',
    }],
    envList,
    selectedEnv: envList?.[0],
    haveCreateCollection: false
  },

  onClickPowerInfo(e) {
    const index = e.currentTarget.dataset.index;
    const powerList = this.data.powerList;
    const selectedItem = powerList[index];
    selectedItem.showItem = !selectedItem.showItem;
    if (selectedItem.link) {
      wx.navigateTo({
        url: `../web/index?url=${selectedItem.link}&title=${selectedItem.title}`,
      });
    } else if (selectedItem.page) {
      wx.navigateTo({
        url: `/pages/${selectedItem.page}/index`,
      });
    }
  },

  jumpPage(e) {
    const { type, page } = e.currentTarget.dataset;
    if (type) {
      wx.navigateTo({
        url: `/pages/exampleDetail/index?envId=${this.data.selectedEnv?.envId}&type=${type}`,
      });
    } else {
      wx.navigateTo({
        url: `/pages/${page}/index?envId=${this.data.selectedEnv?.envId}`,
      });
    }
  }  
});
